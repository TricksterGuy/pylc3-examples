=======
History
=======

0.8.1 (2019-10-05)
------------------

* Official release notes can be found at https://github.com/TricksterGuy/complx/releases/tag/4.18.1

0.1.0 (2018-09-21)
------------------

* First release on PyPI.
