#ifndef VERSION_H
#define VERSION_H

namespace Version {
	static const char FULLVERSION_STRING[] = "4.20.0";
}
#endif
