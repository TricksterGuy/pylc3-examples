#ifndef LC3_OS_HPP
#define LC3_OS_HPP

#include <array>

extern std::array<unsigned short, 0x300> lc3_os;
extern std::array<unsigned short, 0x300> lc3_osv2;

#endif
