=====
Usage
=====

To use pyLC3 in a project::

    import pyLC3
